"""OCR module."""
